package br.com.carolinabartoli.listatarefas_corrigido.model

data class Tarefa(
    var id:String="",
    val nome:String="",
    val oQue:String="",
    val ateQuando:String=""){

}